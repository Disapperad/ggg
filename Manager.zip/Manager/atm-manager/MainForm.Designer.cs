﻿namespace ATMManager
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabPage_transaction = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Operation_Button_Add = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Operations_Cash = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Operations_Date = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.Operations_StartDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.Operations_Type = new System.Windows.Forms.ComboBox();
            this.Operations_Where = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Operations_Search = new System.Windows.Forms.Button();
            this.Operations_AccountNumber = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Data_Operation = new System.Windows.Forms.DataGridView();
            this.Data_Transaction_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data_Transaction_FromIDCard = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data_Transaction_TransactionTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data_Transaction_TransactionType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data_Transaction_ToIDCard = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data_Transaction_Cash = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage_accounts = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Button_SearchAccounts = new System.Windows.Forms.Button();
            this.Accounts_Search_TextBox_FIO = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Accounts_Search_TextBox_Account = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.GroupBox_MoneySelect = new System.Windows.Forms.GroupBox();
            this.Accounts_Search_TextBox_Cash = new System.Windows.Forms.TextBox();
            this.Account_Radio_CashB = new System.Windows.Forms.RadioButton();
            this.Account_Radio_CashM = new System.Windows.Forms.RadioButton();
            this.Account_Radio_CashR = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Button_Accounts_Remove = new System.Windows.Forms.Button();
            this.Button_Accounts_AddAccount = new System.Windows.Forms.Button();
            this.Data_Accounts = new System.Windows.Forms.DataGridView();
            this.AccountsData_Tab_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AccountsData_Tab_AccountID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AccountsData_Tab_PersonName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AccountsData_Tab_Cash = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage_transaction.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Data_Operation)).BeginInit();
            this.tabPage_accounts.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.GroupBox_MoneySelect.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Data_Accounts)).BeginInit();
            this.tabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage_transaction
            // 
            this.tabPage_transaction.Controls.Add(this.groupBox6);
            this.tabPage_transaction.Controls.Add(this.groupBox2);
            this.tabPage_transaction.Controls.Add(this.Data_Operation);
            this.tabPage_transaction.Location = new System.Drawing.Point(4, 29);
            this.tabPage_transaction.Name = "tabPage_transaction";
            this.tabPage_transaction.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_transaction.Size = new System.Drawing.Size(1301, 757);
            this.tabPage_transaction.TabIndex = 3;
            this.tabPage_transaction.Text = "Операции";
            this.tabPage_transaction.UseVisualStyleBackColor = true;
            this.tabPage_transaction.Click += new System.EventHandler(this.tabPage_transaction_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Operation_Button_Add);
            this.groupBox6.Location = new System.Drawing.Point(8, 393);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(282, 66);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Работа со операциями";
            // 
            // Operation_Button_Add
            // 
            this.Operation_Button_Add.Location = new System.Drawing.Point(6, 26);
            this.Operation_Button_Add.Name = "Operation_Button_Add";
            this.Operation_Button_Add.Size = new System.Drawing.Size(270, 29);
            this.Operation_Button_Add.TabIndex = 11;
            this.Operation_Button_Add.Text = "Совершить перевод";
            this.Operation_Button_Add.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.Operations_Cash);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.Operations_Type);
            this.groupBox2.Controls.Add(this.Operations_Where);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.Operations_Search);
            this.groupBox2.Controls.Add(this.Operations_AccountNumber);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(917, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(376, 424);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Тип поиска";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 330);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(260, 20);
            this.label8.TabIndex = 20;
            this.label8.Text = "Денежные средства (Опционально)";
            // 
            // Operations_Cash
            // 
            this.Operations_Cash.Location = new System.Drawing.Point(6, 353);
            this.Operations_Cash.Name = "Operations_Cash";
            this.Operations_Cash.Size = new System.Drawing.Size(363, 27);
            this.Operations_Cash.TabIndex = 10;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Operations_Date);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.Operations_StartDate);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(6, 79);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(363, 141);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Работа с датами";
            // 
            // Operations_Date
            // 
            this.Operations_Date.CustomFormat = "MM/dd/yyyy";
            this.Operations_Date.Enabled = false;
            this.Operations_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Operations_Date.Location = new System.Drawing.Point(6, 99);
            this.Operations_Date.Name = "Operations_Date";
            this.Operations_Date.Size = new System.Drawing.Size(351, 27);
            this.Operations_Date.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 20);
            this.label7.TabIndex = 27;
            this.label7.Text = "Вторая дата";
            // 
            // Operations_StartDate
            // 
            this.Operations_StartDate.CustomFormat = "MM/dd/yyyy";
            this.Operations_StartDate.Enabled = false;
            this.Operations_StartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Operations_StartDate.Location = new System.Drawing.Point(6, 46);
            this.Operations_StartDate.Name = "Operations_StartDate";
            this.Operations_StartDate.Size = new System.Drawing.Size(351, 27);
            this.Operations_StartDate.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Первая дата";
            // 
            // Operations_Type
            // 
            this.Operations_Type.FormattingEnabled = true;
            this.Operations_Type.Location = new System.Drawing.Point(6, 246);
            this.Operations_Type.Name = "Operations_Type";
            this.Operations_Type.Size = new System.Drawing.Size(363, 28);
            this.Operations_Type.TabIndex = 19;
            // 
            // Operations_Where
            // 
            this.Operations_Where.Location = new System.Drawing.Point(6, 300);
            this.Operations_Where.Name = "Operations_Where";
            this.Operations_Where.Size = new System.Drawing.Size(363, 27);
            this.Operations_Where.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 277);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(260, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "Номер счёта (Кому) (Опционально)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 223);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Тип перевода";
            // 
            // Operations_Search
            // 
            this.Operations_Search.Location = new System.Drawing.Point(6, 387);
            this.Operations_Search.Name = "Operations_Search";
            this.Operations_Search.Size = new System.Drawing.Size(363, 29);
            this.Operations_Search.TabIndex = 14;
            this.Operations_Search.Text = "Выполнить поиск";
            this.Operations_Search.UseVisualStyleBackColor = true;
            this.Operations_Search.Click += new System.EventHandler(this.Operations_Search_Click);
            // 
            // Operations_AccountNumber
            // 
            this.Operations_AccountNumber.Location = new System.Drawing.Point(6, 46);
            this.Operations_AccountNumber.Name = "Operations_AccountNumber";
            this.Operations_AccountNumber.Size = new System.Drawing.Size(363, 27);
            this.Operations_AccountNumber.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(271, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Номер счёта (Откуда) (Опционально)";
            // 
            // Data_Operation
            // 
            this.Data_Operation.AllowUserToAddRows = false;
            this.Data_Operation.AllowUserToDeleteRows = false;
            this.Data_Operation.AllowUserToResizeRows = false;
            this.Data_Operation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Data_Operation.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Data_Operation.BackgroundColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Data_Operation.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Data_Operation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Data_Operation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Data_Transaction_ID,
            this.Data_Transaction_FromIDCard,
            this.Data_Transaction_TransactionTime,
            this.Data_Transaction_TransactionType,
            this.Data_Transaction_ToIDCard,
            this.Data_Transaction_Cash});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Data_Operation.DefaultCellStyle = dataGridViewCellStyle2;
            this.Data_Operation.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.Data_Operation.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Data_Operation.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Data_Operation.Location = new System.Drawing.Point(3, 6);
            this.Data_Operation.MultiSelect = false;
            this.Data_Operation.Name = "Data_Operation";
            this.Data_Operation.ReadOnly = true;
            this.Data_Operation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Data_Operation.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Data_Operation.RowHeadersVisible = false;
            this.Data_Operation.RowHeadersWidth = 51;
            this.Data_Operation.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Data_Operation.RowTemplate.Height = 29;
            this.Data_Operation.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Data_Operation.ShowCellErrors = false;
            this.Data_Operation.ShowCellToolTips = false;
            this.Data_Operation.ShowEditingIcon = false;
            this.Data_Operation.ShowRowErrors = false;
            this.Data_Operation.Size = new System.Drawing.Size(906, 381);
            this.Data_Operation.TabIndex = 1;
            // 
            // Data_Transaction_ID
            // 
            this.Data_Transaction_ID.HeaderText = "Номер";
            this.Data_Transaction_ID.MinimumWidth = 6;
            this.Data_Transaction_ID.Name = "Data_Transaction_ID";
            this.Data_Transaction_ID.ReadOnly = true;
            // 
            // Data_Transaction_FromIDCard
            // 
            this.Data_Transaction_FromIDCard.HeaderText = "Откуда";
            this.Data_Transaction_FromIDCard.MinimumWidth = 6;
            this.Data_Transaction_FromIDCard.Name = "Data_Transaction_FromIDCard";
            this.Data_Transaction_FromIDCard.ReadOnly = true;
            // 
            // Data_Transaction_TransactionTime
            // 
            this.Data_Transaction_TransactionTime.HeaderText = "Время операции";
            this.Data_Transaction_TransactionTime.MinimumWidth = 6;
            this.Data_Transaction_TransactionTime.Name = "Data_Transaction_TransactionTime";
            this.Data_Transaction_TransactionTime.ReadOnly = true;
            // 
            // Data_Transaction_TransactionType
            // 
            this.Data_Transaction_TransactionType.HeaderText = "Тип перевода";
            this.Data_Transaction_TransactionType.MinimumWidth = 6;
            this.Data_Transaction_TransactionType.Name = "Data_Transaction_TransactionType";
            this.Data_Transaction_TransactionType.ReadOnly = true;
            // 
            // Data_Transaction_ToIDCard
            // 
            this.Data_Transaction_ToIDCard.HeaderText = "Кому";
            this.Data_Transaction_ToIDCard.MinimumWidth = 6;
            this.Data_Transaction_ToIDCard.Name = "Data_Transaction_ToIDCard";
            this.Data_Transaction_ToIDCard.ReadOnly = true;
            // 
            // Data_Transaction_Cash
            // 
            this.Data_Transaction_Cash.HeaderText = "Количество денежных средств (руб.)";
            this.Data_Transaction_Cash.MinimumWidth = 6;
            this.Data_Transaction_Cash.Name = "Data_Transaction_Cash";
            this.Data_Transaction_Cash.ReadOnly = true;
            // 
            // tabPage_accounts
            // 
            this.tabPage_accounts.Controls.Add(this.groupBox5);
            this.tabPage_accounts.Controls.Add(this.groupBox1);
            this.tabPage_accounts.Controls.Add(this.Data_Accounts);
            this.tabPage_accounts.Location = new System.Drawing.Point(4, 29);
            this.tabPage_accounts.Name = "tabPage_accounts";
            this.tabPage_accounts.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_accounts.Size = new System.Drawing.Size(1301, 757);
            this.tabPage_accounts.TabIndex = 0;
            this.tabPage_accounts.Text = "Счета пользователей";
            this.tabPage_accounts.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Button_SearchAccounts);
            this.groupBox5.Controls.Add(this.Accounts_Search_TextBox_FIO);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.Accounts_Search_TextBox_Account);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.GroupBox_MoneySelect);
            this.groupBox5.Location = new System.Drawing.Point(912, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(381, 381);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Тип поиска";
            // 
            // Button_SearchAccounts
            // 
            this.Button_SearchAccounts.Location = new System.Drawing.Point(6, 296);
            this.Button_SearchAccounts.Name = "Button_SearchAccounts";
            this.Button_SearchAccounts.Size = new System.Drawing.Size(363, 29);
            this.Button_SearchAccounts.TabIndex = 14;
            this.Button_SearchAccounts.Text = "Выполнить поиск";
            this.Button_SearchAccounts.UseVisualStyleBackColor = true;
            this.Button_SearchAccounts.Click += new System.EventHandler(this.Button_SearchAccounts_Click);
            // 
            // Accounts_Search_TextBox_FIO
            // 
            this.Accounts_Search_TextBox_FIO.Location = new System.Drawing.Point(6, 102);
            this.Accounts_Search_TextBox_FIO.Name = "Accounts_Search_TextBox_FIO";
            this.Accounts_Search_TextBox_FIO.Size = new System.Drawing.Size(363, 27);
            this.Accounts_Search_TextBox_FIO.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "ФИО";
            // 
            // Accounts_Search_TextBox_Account
            // 
            this.Accounts_Search_TextBox_Account.Location = new System.Drawing.Point(6, 46);
            this.Accounts_Search_TextBox_Account.Name = "Accounts_Search_TextBox_Account";
            this.Accounts_Search_TextBox_Account.Size = new System.Drawing.Size(363, 27);
            this.Accounts_Search_TextBox_Account.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Номер счёта";
            // 
            // GroupBox_MoneySelect
            // 
            this.GroupBox_MoneySelect.Controls.Add(this.Accounts_Search_TextBox_Cash);
            this.GroupBox_MoneySelect.Controls.Add(this.Account_Radio_CashB);
            this.GroupBox_MoneySelect.Controls.Add(this.Account_Radio_CashM);
            this.GroupBox_MoneySelect.Controls.Add(this.Account_Radio_CashR);
            this.GroupBox_MoneySelect.Location = new System.Drawing.Point(6, 135);
            this.GroupBox_MoneySelect.Name = "GroupBox_MoneySelect";
            this.GroupBox_MoneySelect.Size = new System.Drawing.Size(363, 155);
            this.GroupBox_MoneySelect.TabIndex = 9;
            this.GroupBox_MoneySelect.TabStop = false;
            this.GroupBox_MoneySelect.Text = "Денежные средства";
            // 
            // Accounts_Search_TextBox_Cash
            // 
            this.Accounts_Search_TextBox_Cash.Location = new System.Drawing.Point(6, 26);
            this.Accounts_Search_TextBox_Cash.Name = "Accounts_Search_TextBox_Cash";
            this.Accounts_Search_TextBox_Cash.Size = new System.Drawing.Size(351, 27);
            this.Accounts_Search_TextBox_Cash.TabIndex = 10;
            // 
            // Account_Radio_CashB
            // 
            this.Account_Radio_CashB.AutoSize = true;
            this.Account_Radio_CashB.Location = new System.Drawing.Point(6, 93);
            this.Account_Radio_CashB.Name = "Account_Radio_CashB";
            this.Account_Radio_CashB.Size = new System.Drawing.Size(174, 24);
            this.Account_Radio_CashB.TabIndex = 8;
            this.Account_Radio_CashB.TabStop = true;
            this.Account_Radio_CashB.Text = "> Денежных средств";
            this.Account_Radio_CashB.UseVisualStyleBackColor = true;
            // 
            // Account_Radio_CashM
            // 
            this.Account_Radio_CashM.AutoSize = true;
            this.Account_Radio_CashM.Location = new System.Drawing.Point(6, 123);
            this.Account_Radio_CashM.Name = "Account_Radio_CashM";
            this.Account_Radio_CashM.Size = new System.Drawing.Size(174, 24);
            this.Account_Radio_CashM.TabIndex = 9;
            this.Account_Radio_CashM.TabStop = true;
            this.Account_Radio_CashM.Text = "< Денежных средств";
            this.Account_Radio_CashM.UseVisualStyleBackColor = true;
            // 
            // Account_Radio_CashR
            // 
            this.Account_Radio_CashR.AutoSize = true;
            this.Account_Radio_CashR.Location = new System.Drawing.Point(6, 63);
            this.Account_Radio_CashR.Name = "Account_Radio_CashR";
            this.Account_Radio_CashR.Size = new System.Drawing.Size(174, 24);
            this.Account_Radio_CashR.TabIndex = 7;
            this.Account_Radio_CashR.TabStop = true;
            this.Account_Radio_CashR.Text = "= Денежных средств";
            this.Account_Radio_CashR.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Button_Accounts_Remove);
            this.groupBox1.Controls.Add(this.Button_Accounts_AddAccount);
            this.groupBox1.Location = new System.Drawing.Point(8, 393);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(541, 99);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Работа со счетами";
            // 
            // Button_Accounts_Remove
            // 
            this.Button_Accounts_Remove.Location = new System.Drawing.Point(6, 61);
            this.Button_Accounts_Remove.Name = "Button_Accounts_Remove";
            this.Button_Accounts_Remove.Size = new System.Drawing.Size(529, 29);
            this.Button_Accounts_Remove.TabIndex = 2;
            this.Button_Accounts_Remove.Text = "Удалить запись";
            this.Button_Accounts_Remove.UseVisualStyleBackColor = true;
            this.Button_Accounts_Remove.Click += new System.EventHandler(this.Button_Accounts_Remove_Click);
            // 
            // Button_Accounts_AddAccount
            // 
            this.Button_Accounts_AddAccount.Location = new System.Drawing.Point(6, 26);
            this.Button_Accounts_AddAccount.Name = "Button_Accounts_AddAccount";
            this.Button_Accounts_AddAccount.Size = new System.Drawing.Size(529, 29);
            this.Button_Accounts_AddAccount.TabIndex = 0;
            this.Button_Accounts_AddAccount.Text = "Добавить счёт";
            this.Button_Accounts_AddAccount.UseVisualStyleBackColor = true;
            this.Button_Accounts_AddAccount.Click += new System.EventHandler(this.Button_Accounts_AddAccount_Click);
            // 
            // Data_Accounts
            // 
            this.Data_Accounts.AllowUserToAddRows = false;
            this.Data_Accounts.AllowUserToDeleteRows = false;
            this.Data_Accounts.AllowUserToResizeRows = false;
            this.Data_Accounts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Data_Accounts.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Data_Accounts.BackgroundColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Data_Accounts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.Data_Accounts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Data_Accounts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AccountsData_Tab_ID,
            this.AccountsData_Tab_AccountID,
            this.AccountsData_Tab_PersonName,
            this.AccountsData_Tab_Cash});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Data_Accounts.DefaultCellStyle = dataGridViewCellStyle5;
            this.Data_Accounts.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.Data_Accounts.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Data_Accounts.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Data_Accounts.Location = new System.Drawing.Point(3, 6);
            this.Data_Accounts.MultiSelect = false;
            this.Data_Accounts.Name = "Data_Accounts";
            this.Data_Accounts.ReadOnly = true;
            this.Data_Accounts.RightToLeft = System.Windows.Forms.RightToLeft.No;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Data_Accounts.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.Data_Accounts.RowHeadersVisible = false;
            this.Data_Accounts.RowHeadersWidth = 51;
            this.Data_Accounts.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Data_Accounts.RowTemplate.Height = 29;
            this.Data_Accounts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Data_Accounts.ShowCellErrors = false;
            this.Data_Accounts.ShowCellToolTips = false;
            this.Data_Accounts.ShowEditingIcon = false;
            this.Data_Accounts.ShowRowErrors = false;
            this.Data_Accounts.Size = new System.Drawing.Size(906, 381);
            this.Data_Accounts.TabIndex = 0;
            // 
            // AccountsData_Tab_ID
            // 
            this.AccountsData_Tab_ID.HeaderText = "Номер";
            this.AccountsData_Tab_ID.MinimumWidth = 6;
            this.AccountsData_Tab_ID.Name = "AccountsData_Tab_ID";
            this.AccountsData_Tab_ID.ReadOnly = true;
            // 
            // AccountsData_Tab_AccountID
            // 
            this.AccountsData_Tab_AccountID.HeaderText = "Номер счёта";
            this.AccountsData_Tab_AccountID.MinimumWidth = 6;
            this.AccountsData_Tab_AccountID.Name = "AccountsData_Tab_AccountID";
            this.AccountsData_Tab_AccountID.ReadOnly = true;
            // 
            // AccountsData_Tab_PersonName
            // 
            this.AccountsData_Tab_PersonName.HeaderText = "ФИО";
            this.AccountsData_Tab_PersonName.MinimumWidth = 6;
            this.AccountsData_Tab_PersonName.Name = "AccountsData_Tab_PersonName";
            this.AccountsData_Tab_PersonName.ReadOnly = true;
            // 
            // AccountsData_Tab_Cash
            // 
            this.AccountsData_Tab_Cash.HeaderText = "Деньги на счету (Руб.)";
            this.AccountsData_Tab_Cash.MinimumWidth = 6;
            this.AccountsData_Tab_Cash.Name = "AccountsData_Tab_Cash";
            this.AccountsData_Tab_Cash.ReadOnly = true;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage_accounts);
            this.tabControl.Controls.Add(this.tabPage_transaction);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1309, 790);
            this.tabControl.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1309, 790);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Главная форма";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabPage_transaction.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Data_Operation)).EndInit();
            this.tabPage_accounts.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.GroupBox_MoneySelect.ResumeLayout(false);
            this.GroupBox_MoneySelect.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Data_Accounts)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private TabPage tabPage_transaction;
        private TabPage tabPage_accounts;
        private GroupBox groupBox5;
        private Button Button_SearchAccounts;
        private TextBox Accounts_Search_TextBox_FIO;
        private Label label3;
        private TextBox Accounts_Search_TextBox_Account;
        private Label label2;
        private GroupBox GroupBox_MoneySelect;
        private TextBox Accounts_Search_TextBox_Cash;
        private RadioButton Account_Radio_CashB;
        private RadioButton Account_Radio_CashM;
        private RadioButton Account_Radio_CashR;
        private GroupBox groupBox1;
        private Button Button_Accounts_Remove;
        private Button Button_Accounts_AddAccount;
        public DataGridView Data_Accounts;
        private TabControl tabControl;
        public DataGridView Data_Operation;
        private DataGridViewTextBoxColumn AccountsData_Tab_ID;
        private DataGridViewTextBoxColumn AccountsData_Tab_AccountID;
        private DataGridViewTextBoxColumn AccountsData_Tab_PersonName;
        private DataGridViewTextBoxColumn AccountsData_Tab_Cash;
        private DataGridViewTextBoxColumn Data_Transaction_ID;
        private DataGridViewTextBoxColumn Data_Transaction_FromIDCard;
        private DataGridViewTextBoxColumn Data_Transaction_TransactionTime;
        private DataGridViewTextBoxColumn Data_Transaction_TransactionType;
        private DataGridViewTextBoxColumn Data_Transaction_ToIDCard;
        private DataGridViewTextBoxColumn Data_Transaction_Cash;
        private GroupBox groupBox2;
        private ComboBox Operations_Type;
        private TextBox Operations_Where;
        private Label label6;
        private Label label5;
        private Button Operations_Search;
        private Label label1;
        private TextBox Operations_AccountNumber;
        private Label label4;
        private DateTimePicker Operations_StartDate;
        private TextBox Operations_Cash;
        private GroupBox groupBox4;
        private DateTimePicker Operations_Date;
        private Label label7;
        private GroupBox groupBox6;
        private Button Operation_Button_Add;
        private Label label8;
    }
}