﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;
using ATMManager.Database.Methods;
using System.ComponentModel;

namespace ATMManager.Database.Search
{
    internal static class Search
    {   
        public static void SetGridContent(in DataGridView Grid, in string CommandText,
            in SqlParameter[]? ParameterList = null)
        {
            Grid.Rows.Clear();

            using SqlConnection Connection = new(ConfigurationManager.AppSettings.Get("ConnectionString"));

            SqlCommand CurrentCommand;

            if (ParameterList != null)
            {
                CurrentCommand = MethodList.GetCommandsWithParameters(CommandText, ParameterList);
            }
            else
            {
               CurrentCommand = new(CommandText, Connection);
            }
            
            CurrentCommand.Connection = Connection;

            Connection.Open();

            using SqlDataReader Reader = CurrentCommand.ExecuteReader();

            while (Reader.Read())
            {
                int RowIndex = Grid.Rows.Add();

                for (int i = 0; i < Reader.FieldCount; i++)
                {
                    Grid.Rows[RowIndex].Cells[i].Value = Reader.GetValue(i);
                }
            }
        }

        private class ComboboxItem
        {
            public string? Text { get; set; }
            public object? Value { get; set; }
        }

        public static void SetComboBoxContent(in ComboBox Box, in string CommandText,
    in SqlParameter[]? ParameterList = null)
        {
            Box.Items.Clear();

            using SqlConnection Connection = new(ConfigurationManager.AppSettings.Get("ConnectionString"));

            SqlCommand CurrentCommand;

            if (ParameterList != null)
            {
                CurrentCommand = MethodList.GetCommandsWithParameters(CommandText, ParameterList);
            }
            else
            {
                CurrentCommand = new(CommandText, Connection);
            }

            CurrentCommand.Connection = Connection;

            Connection.Open();

            using SqlDataReader Reader = CurrentCommand.ExecuteReader();
            
            
            BindingList<ComboboxItem> _comboItems = new();

            while (Reader.Read())
            {
                _comboItems.Add(new ComboboxItem { Text = Reader.GetString(1), Value = Reader.GetValue(0) });
            }

            Box.DisplayMember = "Text";
            Box.ValueMember = "Value";
            Box.DataSource = _comboItems;
        }
    }
}
